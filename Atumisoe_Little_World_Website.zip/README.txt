ATUMISOE — A LITTLE WORLD
=========================

This is a small, mobile-first personalized website made for Atumisoe.

PREVIEW
- Open index.html in a browser.
- Keep the assets folder beside index.html so the two photos load.

PUBLISHING
- Netlify: upload the whole unzipped folder (or drag the folder/zip into the deploy area if supported).
- GitHub Pages: upload index.html and the assets folder to a repository, then enable Pages for the main branch/root.

NOTES
- This is a static demo: answers are shown locally on the page and are not saved or sent to Roy.
- Ask permission before sharing her photos publicly; keep the link private if she'd prefer that.
- The page is intentionally light, phone-friendly, and has no tracking or data collection.
